#!/bin/bash
#
#SBATCH --job-name=MoS2_1.6eV
#SBATCH --output=tdpw.out
#SBATCH -N 1 
#SBATCH --ntasks-per-node=36
#SBATCH --time=00:30:00
#SBATCH -p debug

#-------------------Source ----------------------------------------------------------------
module load  mpi/mvapich2/gnu/2.3b
EXEC=/public/home/chendq/soft/gcc-MVAPICH/TDAP-QE-2.2.1/tdpw.x
srun --mpi=pmi2 $EXEC -i input.in  | tee result
